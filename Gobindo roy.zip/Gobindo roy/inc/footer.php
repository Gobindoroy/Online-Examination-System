
</section>
<section class="footeroption">
		<h2>&copy;<?php echo " Gobindo roy"; ?></h2>
		<h2><?php echo " Web design & developer"; ?></h2>
	</section>
</div>
</body>
</html>