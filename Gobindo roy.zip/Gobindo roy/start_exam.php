
<?php include 'inc/header.php'; ?>
<?php 
	Session::checkSession();
	
	$question = $exm->getQuestion();
	$total       = $exm->getTotalRows();
?>

<html>
<head>
	<link rel="stylesheet" href="css/main.css">
</head>
</html>


<div class="main">
<h1>Details This Exam System</h1>
	<div class="starttest">
	<ul>
		
		<li><strong>Total Ques : </strong> <?php echo $total; ?></li>
		<li><strong>Ques Type : </strong> Multiple Choice</li>
	</ul>
	<h4>Subject:Web development.</h4>
	<h4>One minute for each question.</h4>
	<a href="test.php?q=<?php echo $question['quesNo']; ?>">Start Exam</a>	
	</div>
  </div>
<?php include 'inc/footer.php'; ?>