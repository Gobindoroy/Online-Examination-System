<?php include 'inc/header.php'; ?>
<?php 
	Session::checkSession();
?>
<!--************link for css**********-->
<html lang="en">
<head>
	<link rel="stylesheet" href="css/main.css">
</head>
</html>
<!--************End link for css**********-->

<div class="main">
<h1>You are Done    !</h1>
	<div class="starttest">
	<p>Congratulations ! Completed the test.</p>
	<p>Your Score : 
		<?php
			if(isset($_SESSION['score'])){
				echo $_SESSION['score'];
				unset($_SESSION['score']);
			}
		?>
	</p>
	<a href="view_ans.php">View Correct Answer</a>
	<a href="start_exam.php">Again Start Test!!!!</a>
	<a href="Gobindo%20roy/../admin/index.php">Add Question </a>
	</div>
  </div>
<?php include 'inc/footer.php'; ?>