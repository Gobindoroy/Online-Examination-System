<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
?>
<style>
	.main{
		
		
	}
	.adminpanel {
  background: none repeat scroll 0 0 #8CB141;
  border: 2px solid #DDDDDD;
  color: #000;
  font-family: "Times New Roman",Georgia,Serif;
  font-size: 20px;
  margin: 59px auto 0;
  padding: 50px;
  width: 500px;
  text-align: center;
}
</style>
<div class="main">
	<div class = "adminpanel">
		<h2>Welcome To Admin Panel</h2>
	</div>
</div>
<?php include 'inc/footer.php'; ?>