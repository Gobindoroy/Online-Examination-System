-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2018 at 06:39 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_examination`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `adminUser` varchar(50) NOT NULL,
  `adminPass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `adminUser`, `adminPass`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b'),
(2, 'gobindo', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `id` int(11) NOT NULL,
  `quesNo` int(11) NOT NULL,
  `rightAns` int(11) NOT NULL DEFAULT '0',
  `ans` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`id`, `quesNo`, `rightAns`, `ans`) VALUES
(1, 1, 0, 'Strong Question Language  '),
(2, 1, 0, 'Structured Question Language'),
(3, 1, 1, 'Structured Query Language  '),
(4, 1, 0, 'Structure Query Language  '),
(5, 2, 0, 'OPEN  '),
(6, 2, 0, ' GET '),
(7, 2, 0, 'SELECT '),
(8, 2, 1, ' EXTRACT'),
(180, 3, 0, 'MODIFY    '),
(181, 3, 0, ' SAVE AS '),
(182, 3, 0, 'SAVE'),
(183, 3, 1, 'UPDATE'),
(184, 4, 0, 'ADD NEW'),
(185, 4, 0, ' ADD RECORD'),
(186, 4, 1, 'INSERT INTO'),
(187, 4, 0, 'INSERT NEW'),
(188, 5, 0, 'SELECT [all] FROM Persons'),
(189, 5, 1, 'SELECT * FROM Persons'),
(190, 5, 0, 'SELECT Persons'),
(191, 5, 0, 'SELECT *.Persons'),
(192, 6, 1, 'h1 tag'),
(193, 6, 0, 'h6 tag'),
(194, 6, 0, 'head tag'),
(195, 6, 0, 'headind  tag'),
(196, 7, 0, '.'),
(197, 7, 1, '/'),
(198, 7, 0, ':'),
(199, 7, 0, '*'),
(200, 8, 0, ' Creative Style Sheets    '),
(201, 8, 1, 'Cascading Style Sheets'),
(202, 8, 0, 'Computer Style Sheets'),
(203, 8, 0, 'Colorful Style Sheets  '),
(204, 9, 0, 'styles '),
(205, 9, 0, ' class '),
(206, 9, 0, 'font  '),
(207, 9, 1, 'style'),
(212, 10, 0, 'bgcolor'),
(213, 10, 1, ' background-color'),
(214, 10, 0, 'color'),
(215, 10, 0, 'background'),
(216, 11, 0, 'text-color '),
(217, 11, 1, ' color'),
(218, 11, 0, '  fgcolor'),
(219, 11, 0, 'bg_color'),
(220, 12, 1, ' font-size     '),
(221, 12, 0, ' text-size'),
(222, 12, 0, 'font-style'),
(223, 12, 0, 'text-style'),
(224, 13, 0, 'Both font-family and font can be used'),
(225, 13, 0, ' font'),
(226, 13, 1, ' font-family'),
(227, 13, 0, 'text-family'),
(228, 14, 0, 'font- style:bold;'),
(229, 14, 0, ' font:bold;'),
(230, 14, 0, ' style:bold;'),
(231, 14, 1, 'font-weight:bold; '),
(232, 15, 0, 'msgBox(\"Hello World\");'),
(233, 15, 0, 'msg(\"Hello World\");'),
(234, 15, 1, 'alert(\"Hello World\");'),
(235, 15, 0, 'alertBox(\"Hello World\");'),
(236, 16, 0, 'function myFunction() ;'),
(237, 16, 0, ' function = myFunction()'),
(238, 16, 0, '  function:myFunction()'),
(239, 16, 1, 'function myFunction() '),
(240, 17, 0, '\"Hello World\";'),
(241, 17, 0, 'Document.Write(\"Hello World\");'),
(242, 17, 1, 'echo \"Hello World\";'),
(243, 17, 0, 'echo \"(Hello World)\";'),
(244, 18, 1, ';'),
(245, 18, 0, '.'),
(246, 18, 0, 'new line'),
(247, 18, 0, '+'),
(248, 19, 0, '$count =+1'),
(249, 19, 0, '++count'),
(250, 19, 0, '$count++;'),
(251, 19, 1, 'count++;'),
(252, 20, 0, '$myVar'),
(253, 20, 0, '$my_Var'),
(254, 20, 0, '$myvar'),
(255, 20, 1, ' $my-Var');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `quesNo` int(11) NOT NULL,
  `ques` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `quesNo`, `ques`) VALUES
(1, 1, 'What does SQL stand for?'),
(2, 2, 'Which SQL statement is used to extract data from a database?'),
(53, 3, ' Which SQL statement is used to update data in a database?'),
(54, 4, 'Which SQL statement is used to insert new data in a database?'),
(55, 5, 'With SQL, how do you select all the columns from a table named \"Persons\"?'),
(56, 6, ' Choose the correct HTML element for the largest heading:'),
(57, 7, 'Which character is used to indicate an end tag?'),
(58, 8, 'What does CSS stand for?'),
(59, 9, 'Which HTML attribute is used to define inline styles?'),
(63, 10, 'Which property is used to change the background color?'),
(64, 11, 'Which CSS property is used to change the text color of an element?'),
(65, 12, 'Which CSS property controls the text size?'),
(66, 13, 'Which property is used to change the font of an element?'),
(67, 14, ' How do you make the text bold?'),
(68, 15, 'How do you write \"Hello World\" in an alert box?'),
(69, 16, 'How do you create a function in JavaScript?'),
(70, 17, ' How do you write \"Hello World\" in PHP'),
(71, 18, ' What is the correct way to end a PHP statement?'),
(72, 19, 'What is the correct way to add 1 to the $count variable?'),
(73, 20, 'Which one of these variables has an illegal name?');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `username`, `password`, `email`, `status`) VALUES
(8, 'Gobindo roy', 'gobindo', '827ccb0eea8a706c4c34a16891f84e7b', 'gobindo@gmail.com', 0),
(17, 'Partho roy', 'partho', 'a4b500f5f0c488ded0efeeb422144f71', 'partho340@gmail.com', 0),
(19, 'Sadhon roy', 'sadhon', '20feb688c09c36fc906624bc3f53ceb2', 'sadhon@gmail.com', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=256;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
