<?php include 'inc/header.php'; ?>
<?php 
	Session::checkSession();
?>
<div class="main">
<h1>Welcome to Online Examination </h1>
	<div class="segment">
	<h2>Please Click To Start Now Button </h2>
	<ul>
		<li><a href="start_exam.php">Start Now...</a></li>
	</ul>
	</div>
	
  </div>
<?php include 'inc/footer.php'; ?>