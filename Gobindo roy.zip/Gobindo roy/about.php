<?php include 'inc/header.php'; ?>
<?php 
	Session::checkSession();
?>
<!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>Document</title>
 	<link rel="stylesheet" href="css/profile.css">
 </head>
 <body>
 	<div class="main">
	<div class="about">
    <h2>About me</h2>
				<img src="img/pttt.jpg" alt="img">
				
     <div class="about_p"><p>I am <strong>Gobindo Roy </strong>......I am completed <b>Diploma engineering</b> with first class on CSE in Dinajpur polytechnic institute. 
     I wish I would be a skilled <b>software developer</b>. I would love to work honestly for the welfare of the country and utilize my highest merit throughout my life.</p></div>
     <h3>Languages Skill:</h3>
     <h5>HTML,CSS,JS.BOOTSTRAP,JQUERY,MYSQL,PHP</h5>
     <h3>Software Skill:</h3>
     <h5> PHOTOSHOP,ILLUSTRATOR,MS WORD,MS POWERPOINT,MS EXCEL,SUBLIME TEXT,NOTEPADE++</h5>

     <h3>Languages:</h3>
      <h5>English,Bangla</h5>
      <h3>Training Summary:</h3>
      <h5>Web design & development,LICT 02.12.2017 - 30.03.2018</h5>
      <h5>Web design & development,LEGEND E And T.C Rangpur 01.07.2017 - 30.10.2017</h5>
      




      <h3>My Academic Qualification:</h3>
         <table class="tbl_about">
          <tr>
            <th>Exam Title:</th>
            <th>Concentration/Major:</th>
            <th>Institute:</th>
            <th>Result:</th>
            <th>Pass-Year:</th>
            
          </tr>
          <tr>
            <td>Graduation:</td>
            <td>Diploma engineering</td>
            <td>Dinajpur polytechnic institute</td>
            <td>3.50</td>
            <td>2017</td>
            
          </tr>
          <tr>
            <td>SSC:</td>
            <td>SSC</td>
            <td>Bagdokra Nimojkhana school & college</td>
            <td>4.81</td>
            <td>2013</td>
            
          </tr>
        </table>
        <h3>Contuct me:</h3>
        <h5>Mobile:01784288097,01755166148,01571702431</h5>
        <h5>Facebook:Biswase partho</h5>
        <h5>Email:roygobindo@gmail.com</h5>
			</div>
		</div>

<?php include 'inc/footer.php'; ?>
 </body>
 </html>

