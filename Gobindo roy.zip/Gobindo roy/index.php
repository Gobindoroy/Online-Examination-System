<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/profile.css">
</head>
<body>
<!--              
***************************************************
***   Program Name: Online Examination System   ***
***   Prgramar : Gobindo roy                    ***
***   Create Date: 28-feb-2018                  ***
***   Ceavts: None                              ***
***   Title:  Student Authentication            ***
***************************************************
-->


	<div class="main all ">
	<div class="banner all ">
		<div class="img" >
			<img src="img/welcome.png" alt="banner">
		</div>
	</div>
	<div class="mainsection all hidden ">
	<div class="section">
		<div class="leftsidebar hidden">

			  <!--js slides-->

			<h2>Slides Of Exam</h2>
			<div class="section hidden">
               <img class="mySlides" src="img/post1.jpg" style="width: 100%">
               <img class="mySlides" src="img/post2.jpg" style="width: 100%">
               <img class="mySlides" src="img/post3.jpg" style="width: 100%">
               <img class="mySlides" src="img/post4.jpg" style="width: 100%">
               <img class="mySlides" src="img/post5.jpg" style="width: 100%">
            </div>
		</div>
		    <!--Right sidebar-->

		<div class="rigt hidden">
			<p>Click resister for online login</p>
			<a href="login.php"><img src="img/regi.jpg" alt="img"></a>
		</div>
	</div>
	</div>
              <!--Footer section-->
     <div class="footer_section all">
	<div class="footer all ">
		<h2>&copy; Gobindo roy</h2>
		<h2>Web design & developer</h2>
	</div>
	</div>
	</div>
	<!--slider section js-->
	<script>
		var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
   </script>
</body>
</html>